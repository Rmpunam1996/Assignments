import React from "react";

const Filter = ({ filter, setFilter }) => {
  return (
    <div className="filters">
      <button disabled={filter === "all"} onClick={() => setFilter("all")}>
        All
      </button>
      <button
        disabled={filter === "completed"}
        onClick={() => setFilter("completed")}
      >
        Completed
      </button>
      <button
        disabled={filter === "pending"}
        onClick={() => setFilter("pending")}
      >
        Pending
      </button>
    </div>
  );
};

export default Filter;
